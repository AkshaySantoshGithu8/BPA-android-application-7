package edu.utdallas.bpaloginpage;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.appcheck.interop.BuildConfig;

public class AppInformationActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_information);

        // Set app information
        TextView versionTextView = findViewById(R.id.versionTextView);
        versionTextView.setText("Version: " + BuildConfig.VERSION_NAME);

        TextView authorTextView = findViewById(R.id.authorTextView);
        ImageView imageView = findViewById(R.id.profileImageView);


       imageView.setRotation(360);
        // Add more TextViews and set additional information as needed
    }
}
