package edu.utdallas.bpaloginpage;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class PasswordActivity extends AppCompatActivity {

    private EditText currentPasswordEditText, newPasswordEditText, confirmPasswordEditText;
    private Button changePasswordButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);

        // Initialize Views
        currentPasswordEditText = findViewById(R.id.currentPasswordEditText);
        newPasswordEditText = findViewById(R.id.newPasswordEditText);
        confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText);
        changePasswordButton = findViewById(R.id.changePasswordButton);

        // Set click listener for the change password button
        changePasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changePassword();
            }
        });
    }

    private void changePassword() {
        String currentPassword = currentPasswordEditText.getText().toString().trim();
        String newPassword = newPasswordEditText.getText().toString().trim();
        String confirmPassword = confirmPasswordEditText.getText().toString().trim();

        // Check if the new password and confirm password match
        if (!newPassword.equals(confirmPassword)) {
            Toast.makeText(this, "New password and confirm password do not match.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if the current password is correct (you may need to implement your authentication logic)
        if (!(LoginActivity.currentPass.equals( currentPasswordEditText.getText().toString().trim()))) {
            Log.d("PasswordActivity", currentPasswordEditText.getText().toString().trim() + LoginActivity.currentPass);

            Toast.makeText(this, "Current password is incorrect.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Update the password in Firestore
        updatePassword(newPassword);
    }




    private void updatePassword(String newPassword) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String currentUser = LoginActivity.currentUser;

        // Reference to the document in the "passwords" collection
        DocumentReference userDocRef = db.collection("passwords").document(currentUser);

        // Update the password field in Firestore
        userDocRef.update("password", newPassword)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        LoginActivity.currentPass=newPasswordEditText.getText().toString();
                        Toast.makeText(PasswordActivity.this, "Password updated successfully.", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("PasswordActivity", currentPasswordEditText.getText().toString().trim());
                        Toast.makeText(PasswordActivity.this, "Failed to update password.", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
