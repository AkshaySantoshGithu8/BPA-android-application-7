package edu.utdallas.bpaloginpage;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class EventCreatorActivity extends AppCompatActivity {
    private EditText NameEditText, DateEditText, TimeEditText;
    private EditText LocationEditText, DescriptionEditText;
    private Button saveButton, loginButton;
    private FirebaseFirestore db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_creator);

        // Initialize your views
        NameEditText = findViewById(R.id.NameEditText);
        DateEditText = findViewById(R.id.DateEditText);
        TimeEditText = findViewById(R.id.TimeEditText);
        LocationEditText = findViewById(R.id.LocationEditText);
       DescriptionEditText = findViewById(R.id.DescriptionEditText);
        saveButton = findViewById(R.id.saveButton);
        loginButton = findViewById(R.id.loginButton);  // Initialize loginButton

        db = FirebaseFirestore.getInstance();

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Your login logic...

                // Create an intent to start LoginActivity
                Intent intent = new Intent(EventCreatorActivity.this, HomepageActivity.class);
                startActivity(intent);
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveData();
            }
        });
    }
    private void createNewDocument(String name, String date, String time, String location, String description) {
        // Create a new document with the specified fields
        Map<String, Object> data = new HashMap<>();
        data.put("Name", name);
        data.put("Date", date);
        data.put("Time", time);
        data.put("Location", location);
        data.put("Description", description);

        // Use the username as the document ID
        db.collection("events")
                .document(name)
                .set(data)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(EventCreatorActivity.this, "Data saved successfully", Toast.LENGTH_SHORT).show();
                            LocationEditText.setText("");
                            DescriptionEditText.setText("");
                            NameEditText.setText("");
                            DateEditText.setText("");
                            TimeEditText.setText("");
                        } else {
                            Toast.makeText(EventCreatorActivity.this, "Failed to save data: " + task.getException(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }


    private void saveData() {
        final String username = LocationEditText.getText().toString().trim();
        String password = DescriptionEditText.getText().toString().trim();
        String firstName = NameEditText.getText().toString().trim();
        String lastName = DateEditText.getText().toString().trim();
        String email = TimeEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty() || firstName.isEmpty() || lastName.isEmpty() || email.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if the document already exists
        db.collection("events")
                .document(username)
                .get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                // Document with the given username already exists
                                Toast.makeText(EventCreatorActivity.this, "User already exists", Toast.LENGTH_SHORT).show();
                            } else {
                                // Document does not exist, create a new one
                                createNewDocument(username, password, firstName, lastName, email);
                            }
                        } else {
                            Toast.makeText(EventCreatorActivity.this, "Failed to check document existence", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

    }



}
