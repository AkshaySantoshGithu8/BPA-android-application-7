package edu.utdallas.bpaloginpage;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.Objects;

public class EventDetailsActivity extends AppCompatActivity {

    private LinearLayout eventsLayout;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_details);

        eventsLayout = findViewById(R.id.eventsLayout);
        db = FirebaseFirestore.getInstance();

        // Retrieve all documents from the "events" collection
        db.collection("events")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            // Iterate through each document in the result
                            for (DocumentSnapshot document : Objects.requireNonNull(task.getResult())) {
                                displayEventDetails(document);
                            }
                        } else {
                            // Handle errors
                            Toast.makeText(EventDetailsActivity.this, "Error: " + task.getException(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void displayEventDetails(DocumentSnapshot document) {
        // Inflate the custom layout for each event
        View eventView = LayoutInflater.from(this).inflate(R.layout.item_event, null);

// Set the details for each event
        TextView eventNameTextView = eventView.findViewById(R.id.eventNameTextView);
        eventNameTextView.setText("Event Name: " + document.getString("Name"));

        TextView eventDateTextView = eventView.findViewById(R.id.eventDateTextView);
        eventDateTextView.setText("Event Date: " + document.getString("Date"));

        TextView eventTimeTextView = eventView.findViewById(R.id.eventTimeTextView);
        eventTimeTextView.setText("Event Time: " + document.getString("Time"));

        TextView eventLocationTextView = eventView.findViewById(R.id.eventLocationTextView);
        eventLocationTextView.setText("Event Location: " + document.getString("Location"));

        TextView eventDescriptionTextView = eventView.findViewById(R.id.eventDescriptionTextView);
        eventDescriptionTextView.setText("Event Description: " + document.getString("Description"));

// Set normal typeface for text after the colon


        TextView contactInfoTextView = eventView.findViewById(R.id.contactInfoTextView);
        try {
            contactInfoTextView.setText("Contact Info: " + document.getString("contactInfo"));
        }
        catch(Exception io){
        // Fetch the "email" field from the corresponding document in "passwords" collection
        String currentUser = LoginActivity.currentUser;
        FirebaseFirestore.getInstance().collection("passwords")
                .document(currentUser)
                .get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot passwordDocument = task.getResult();
                            if (passwordDocument.exists()) {
                                String email = passwordDocument.getString("email");

                                contactInfoTextView.setText("Contact Info: " + email);
                            }
                        } else {
                            // Handle errors
                            Toast.makeText(EventDetailsActivity.this, "Error: " + task.getException(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });}

        // Add the eventView to the eventsLayout

        eventsLayout.addView(eventView);
    }




}
