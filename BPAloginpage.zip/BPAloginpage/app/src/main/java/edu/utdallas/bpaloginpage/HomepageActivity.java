package edu.utdallas.bpaloginpage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.work.Constraints;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public class HomepageActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();

        // Create a periodic work request to run the EventCleanupWorker every day
        PeriodicWorkRequest workRequest = new PeriodicWorkRequest.Builder(
                EventCleanupWorker.class,
                1, TimeUnit.DAYS)
                .setConstraints(constraints)
                .build();

        // Enqueue the periodic work request
        WorkManager.getInstance(this).enqueue(workRequest);
        // Use the correct layout for MainActivity
        setContentView(R.layout.activity_homepage);

        CardView myCardView = findViewById(R.id.myCardView);

        // Set up a click listener for the CardView
        myCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start HomepageActivity when the CardView is clicked
                startActivity(new Intent(HomepageActivity.this, EventCreatorActivity.class));
            }
        });

        CardView yourCardView = findViewById(R.id.yourCardView);
        yourCardView.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            // Start HomepageActivity when the CardView is clicked
            startActivity(new Intent(HomepageActivity.this, EventDetailsActivity.class));
        }
    });


        CardView accountCardView = findViewById(R.id.accountCardView);
        accountCardView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                // Start HomepageActivity when the CardView is clicked
                startActivity(new Intent(HomepageActivity.this, RecoverHomepageActivity.class));
            }
        });

        CardView calendarCardView = findViewById(R.id.myCalendar);

        calendarCardView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                // Start HomepageActivity when the CardView is clicked
                startActivity(new Intent(HomepageActivity.this, SetActivity.class));
            }
        });
        CardView AppCardView = findViewById(R.id.myApp);

        AppCardView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                // Start HomepageActivity when the CardView is clicked
                startActivity(new Intent(HomepageActivity.this, AppInformationActivity.class));
            }
        });
    }


    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
