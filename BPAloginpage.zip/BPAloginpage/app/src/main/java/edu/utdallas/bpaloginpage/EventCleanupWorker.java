package edu.utdallas.bpaloginpage;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class EventCleanupWorker extends Worker {
    public EventCleanupWorker(
            @NonNull Context context,
            @NonNull WorkerParameters params
    ) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        // Implement the logic to clean up old events here
        // This method runs in the background
        cleanupOldEvents();
        cleanupOldCalendar();
        return Result.success();
    }

    private void cleanupOldCalendar() {
        // Get the current date and time
        Date currentDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());

        // Reference to the main collection
        CollectionReference mainCollectionRef = FirebaseFirestore.getInstance()
                .collection("saveEventOnCalendar")
                .document(LoginActivity.currentUser)
                .collection("events");

        // Get events from the main collection
        mainCollectionRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                for (DocumentSnapshot document : task.getResult()) {
                    // Check if the event is old
                    String dateString = document.getString("Date");
                    String timeString = document.getString("Time");
                    try {
                        Date eventDate = dateFormat.parse(dateString);
                        Date eventTime = timeFormat.parse(timeString);

                        if (eventDate.before(currentDate) || (eventDate.equals(currentDate) && eventTime.before(currentDate))) {
                            // Delete the old event
                            mainCollectionRef.document(document.getId()).delete();
                        }
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }
    private void cleanupOldEvents() {
        // Get the current date and time
        Date currentDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());

        // Reference to the main collection
        CollectionReference mainCollectionRef = FirebaseFirestore.getInstance()
                .collection("events");

        // Get events from the main collection
        mainCollectionRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                for (DocumentSnapshot document : task.getResult()) {
                    // Check if the event is old
                    String dateString = document.getString("Date");
                    String timeString = document.getString("Time");
                    try {
                        Date eventDate = dateFormat.parse(dateString);
                        Date eventTime = timeFormat.parse(timeString);

                        if (eventDate.before(currentDate) || (eventDate.equals(currentDate) && eventTime.before(currentDate))) {
                            // Delete the old event
                            mainCollectionRef.document(document.getId()).delete();
                        }
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }
}
