package edu.utdallas.bpaloginpage;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.google.firebase.firestore.PropertyName;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.Serializable;
import java.lang.reflect.Type;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Event implements Serializable {
    public static ArrayList<Event> eventsList = new ArrayList<>();

    @PropertyName("Name")
    private String name;
    @PropertyName("Date")
    private String date;
    @PropertyName("Time")
    private String time;
    private String documentId; // Store the document ID

    public Event(String name, String date, String time) {
        this.name = name;
        this.date = date;
        this.time = time;
    }

    // Empty constructor for Firestore
    public Event() {}

    // Your existing methods...

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public static void saveEventsList(Context context) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = preferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(eventsList);
        editor.putString("eventsList", json);
        editor.apply();
    }

    public static void loadEventsList(Context context) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        Gson gson = new Gson();
        String json = preferences.getString("eventsList", "");
        Type type = new TypeToken<ArrayList<Event>>() {}.getType();
        eventsList = gson.fromJson(json, type);
        if (eventsList == null) {
            eventsList = new ArrayList<>();
        }
    }

    public List<HourEvent> getEvents() {
        return (ArrayList) eventsList;
    }
}
