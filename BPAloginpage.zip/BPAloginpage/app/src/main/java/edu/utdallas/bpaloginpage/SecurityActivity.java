package edu.utdallas.bpaloginpage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class SecurityActivity extends AppCompatActivity {

    private EditText recoveryEmailEditText, answer1EditText, answer2EditText, answer3EditText;
    private Spinner securityQuestion1Spinner, securityQuestion2Spinner, securityQuestion3Spinner;
    private Button authenticateButton;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_security);

        recoveryEmailEditText = findViewById(R.id.recoveryEmailEditText);
        answer1EditText = findViewById(R.id.answer1EditText);
        answer2EditText = findViewById(R.id.answer2EditText);
        answer3EditText = findViewById(R.id.answer3EditText);
        securityQuestion1Spinner = findViewById(R.id.securityQuestion1Spinner);
        securityQuestion2Spinner = findViewById(R.id.securityQuestion2Spinner);
        securityQuestion3Spinner = findViewById(R.id.securityQuestion3Spinner);
        authenticateButton = findViewById(R.id.authenticateButton);

        db = FirebaseFirestore.getInstance();

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.security_questions, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        securityQuestion1Spinner.setAdapter(adapter);
        securityQuestion2Spinner.setAdapter(adapter);
        securityQuestion3Spinner.setAdapter(adapter);

        authenticateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                authenticateUser();
            }
        });
    }

    private void authenticateUser() {
        String recoveryEmail = recoveryEmailEditText.getText().toString().trim();
        String answer1 = answer1EditText.getText().toString().trim();
        String answer2 = answer2EditText.getText().toString().trim();
        String answer3 = answer3EditText.getText().toString().trim();

        // Query the database for documents with matching recovery email
        db.collection("passwords")
                .whereEqualTo("email", recoveryEmail)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful() && !task.getResult().isEmpty()) {
                            // Loop through the results to find the correct answers
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String correctAnswer1 = document.getString("security1");
                                String correctAnswer2 = document.getString("security2");
                                String correctAnswer3 = document.getString("security3");

                                // Check if the entered answers match any permutation
                                if ((answer1.equals(correctAnswer1) && answer2.equals(correctAnswer2) && answer3.equals(correctAnswer3)) ||
                                        (answer1.equals(correctAnswer1) && answer2.equals(correctAnswer3) && answer3.equals(correctAnswer2)) ||
                                        (answer1.equals(correctAnswer2) && answer2.equals(correctAnswer1) && answer3.equals(correctAnswer3)) ||
                                        (answer1.equals(correctAnswer2) && answer2.equals(correctAnswer3) && answer3.equals(correctAnswer1)) ||
                                        (answer1.equals(correctAnswer3) && answer2.equals(correctAnswer1) && answer3.equals(correctAnswer2)) ||
                                        (answer1.equals(correctAnswer3) && answer2.equals(correctAnswer2) && answer3.equals(correctAnswer1))) {
                                    // Authentication successful, launch the next activity
                                    Intent intent = new Intent(SecurityActivity.this, HomepageActivity.class);
                                    startActivity(intent);
                                    finish(); // Optional: Finish the current activity
                                    return;
                                }
                            }

                            // Authentication failed
                            Toast.makeText(SecurityActivity.this, "Authentication failed", Toast.LENGTH_SHORT).show();
                        } else {
                            // Authentication failed
                            Toast.makeText(SecurityActivity.this, "Authentication failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}
