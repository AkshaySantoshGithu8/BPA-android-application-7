package edu.utdallas.bpaloginpage;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class HourAdapter extends ArrayAdapter<HourEvent> {
    public HourAdapter(@NonNull Context context, List<HourEvent> hourEvents) {
        super(context, 0, hourEvents);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.hour_cell, parent, false);
        }

        HourEvent event = getItem(position);

        if (event != null) {
            setHour(convertView, event.getTime());
            setDate(convertView, event.getDate());
            setName(convertView, event.getName());
            setEvents(convertView, event.getEvents());
        }

        return convertView;
    }

    private void setHour(View convertView, LocalTime time) {
        TextView timeTV = convertView.findViewById(R.id.timeTV);
        timeTV.setText(CalendarUtils.formattedShortTime(time));
    }
    private void setDate(View convertView, String date) {
        TextView dateTV = convertView.findViewById(R.id.dateTV);
        dateTV.setText(date);
    }
    private void setName(View convertView, String name) {
        TextView eventCellTV = convertView.findViewById(R.id.eventCellTV);
        eventCellTV.setText(name);
    }



    private void setEvents(View convertView, List<Event> events) {
        TextView event1 = convertView.findViewById(R.id.dateTV);
        TextView event2 = convertView.findViewById(R.id.timeTV);
        TextView event3 = convertView.findViewById(R.id.eventCellTV);

        // The rest of your setEvents method remains unchanged
        // ...
    }
    private void hideEvent(TextView tv)
    {
        tv.setVisibility(View.INVISIBLE);
    }

}
