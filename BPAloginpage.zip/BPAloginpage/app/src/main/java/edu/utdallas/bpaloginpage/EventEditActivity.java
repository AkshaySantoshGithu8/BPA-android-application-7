package edu.utdallas.bpaloginpage;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.Map;

public class EventEditActivity extends AppCompatActivity {
    private EditText eventNameET;
    private TextView eventDateTV, eventTimeTV;
    private TimePicker timePicker;
    private LocalDate selectedDate;
    private LocalTime selectedTime;
    private int eventNumber = 1; // Starting event number

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_edit);
        Event.loadEventsList(this);
        initWidgets();
        initDateTime(); // Initialize date and time
    }

    private void initWidgets() {
        eventNameET = findViewById(R.id.eventNameET);
        eventDateTV = findViewById(R.id.eventDateTV);
        eventTimeTV = findViewById(R.id.eventTimeTV);
        timePicker = findViewById(R.id.timePicker);
        timePicker.setIs24HourView(true);

        timePicker.setOnTimeChangedListener((view, hourOfDay, minute) -> {
            selectedTime = LocalTime.of(hourOfDay, minute);
            updateEventTime();
        });
    }

    private void initDateTime() {
        selectedDate = CalendarUtils.selectedDate;
        selectedTime = LocalTime.now();

        eventDateTV.setText("Date: " + CalendarUtils.formattedDate(selectedDate));
        updateEventTime();
    }

    private void updateEventTime() {
        eventTimeTV.setText("Time: " + CalendarUtils.formattedTime(selectedTime));
    }

    public void saveEventAction(View view) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference eventsRef = db.collection("saveEventOnCalendar")
                .document(LoginActivity.currentUser)
                .collection("events");

        eventsRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    int eventNumber = task.getResult().size() + 1;
                    String eventName = "event" + eventNumber;
                    String saveName = eventNameET.getText().toString();
                    String formattedTime = CalendarUtils.formattedShortTime(selectedTime);

                    Map<String, Object> data = new HashMap<>();
                    data.put("Date", selectedDate.toString());
                    data.put("Time", formattedTime);
                    data.put("Name", saveName);

                    // Save the event to Firestore
                    eventsRef.document(eventName)
                            .set(data)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(EventEditActivity.this, "Data saved successfully", Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(EventEditActivity.this, "Failed to save data: " + task.getException(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });

                    Log.d("EventEditActivity", "Event Name: " + eventName);
                    Log.d("EventEditActivity", "Formatted Time: " + formattedTime);

                    startActivity(new Intent(EventEditActivity.this, WeekViewActivity.class));
                } else {
                    // Handle errors
                }
            }
        });
    }
}
