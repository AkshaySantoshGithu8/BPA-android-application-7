package edu.utdallas.bpaloginpage;

import com.google.firebase.firestore.PropertyName;

import java.io.Serializable;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class HourEvent implements Serializable {
    @PropertyName("Time")
    private String timeAsString; // Use String for Firestore storage
    @PropertyName("Name")
    private String name;
    @PropertyName("Date")
    private String date;
    private List<Event> events;

    public HourEvent(String time, String date, String name, List<Event> events) {
        timeAsString = time;
        this.events = events;
        this.date=date;
        this.name = name;
    }

    // Empty constructor for Firestore
    public HourEvent() {}
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
    public LocalTime getTime() {
        return LocalTime.parse(timeAsString);
    }

    public void setTime(LocalTime time) {
        this.timeAsString = time.toString();
    }

    public List<Event> getEvents() {
        return events;
    }

    public void setEvents(List<Event> events) {
        this.events = events;
    }
}
