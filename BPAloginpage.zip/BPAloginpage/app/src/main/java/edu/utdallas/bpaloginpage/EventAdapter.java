package edu.utdallas.bpaloginpage;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class EventAdapter extends ArrayAdapter<Event> {
    private List<Event> events;

    public EventAdapter(@NonNull Context context, List<Event> events) {
        super(context, 0, events);
        this.events = events;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Event event = getItem(position);

        if (convertView == null)
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.event_cell, parent, false);

        TextView eventCellTV = convertView.findViewById(R.id.eventCellTV);
        TextView timeTV = convertView.findViewById(R.id.timeTV);
        TextView dateTV = convertView.findViewById(R.id.dateTV);

       // String eventTitle = event.getName() + " " + event.getTime() + " " + event.getDate();
        eventCellTV.setText(event.getName());
        timeTV.setText(event.getTime());
        dateTV.setText(event.getDate());
        return convertView;
    }

    // Add this method to set the events
    public void setEvents(List<Event> events) {
        this.events = events;
    }
}
