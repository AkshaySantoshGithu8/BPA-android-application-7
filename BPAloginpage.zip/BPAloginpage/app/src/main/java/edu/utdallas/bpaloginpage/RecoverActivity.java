package edu.utdallas.bpaloginpage;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class RecoverActivity extends AppCompatActivity {

    private Spinner securityQuestion1Spinner, securityQuestion2Spinner, securityQuestion3Spinner;
    private EditText answer1EditText, answer2EditText, answer3EditText;
    private Button saveAnswersButton;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recover);

        securityQuestion1Spinner = findViewById(R.id.securityQuestion1Spinner);
        securityQuestion2Spinner = findViewById(R.id.securityQuestion2Spinner);
        securityQuestion3Spinner = findViewById(R.id.securityQuestion3Spinner);
        answer1EditText = findViewById(R.id.answer1EditText);
        answer2EditText = findViewById(R.id.answer2EditText);
        answer3EditText = findViewById(R.id.answer3EditText);
        saveAnswersButton = findViewById(R.id.saveAnswersButton);

        db = FirebaseFirestore.getInstance();

        // Spinner options for security questions
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.security_questions, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Set adapter for each spinner
        securityQuestion1Spinner.setAdapter(adapter);
        securityQuestion2Spinner.setAdapter(adapter);
        securityQuestion3Spinner.setAdapter(adapter);

        // Set spinner item selected listeners
        setSpinnerItemSelectedListener(securityQuestion1Spinner);
        setSpinnerItemSelectedListener(securityQuestion2Spinner);
        setSpinnerItemSelectedListener(securityQuestion3Spinner);

        saveAnswersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSecurityAnswers();
            }
        });
    }

    private void setSpinnerItemSelectedListener(Spinner spinner) {
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // Handle item selection if needed
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Do nothing here
            }
        });
    }

    private void saveSecurityAnswers() {
        String securityQuestion1 = securityQuestion1Spinner.getSelectedItem().toString();
        String securityQuestion2 = securityQuestion2Spinner.getSelectedItem().toString();
        String securityQuestion3 = securityQuestion3Spinner.getSelectedItem().toString();
        String answer1 = answer1EditText.getText().toString().trim();
        String answer2 = answer2EditText.getText().toString().trim();
        String answer3 = answer3EditText.getText().toString().trim();

        // Check if the answers are not empty
        if (answer1.isEmpty() || answer2.isEmpty() || answer3.isEmpty()) {
            Toast.makeText(this, "Please answer all security questions", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a new map with the security question answers
        Map<String, Object> securityAnswers = new HashMap<>();
        securityAnswers.put("securityQuestion1", securityQuestion1);
        securityAnswers.put("securityAnswer1", answer1);
        securityAnswers.put("securityQuestion2", securityQuestion2);
        securityAnswers.put("securityAnswer2", answer2);
        securityAnswers.put("securityQuestion3", securityQuestion3);
        securityAnswers.put("securityAnswer3", answer3);

        // Update the current document in the "passwords" collection with the security answers
        String currentUsername = LoginActivity.currentUser;
        db.collection("passwords")
                .document(currentUsername)
                .update(securityAnswers)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(RecoverActivity.this, "Security answers saved successfully", Toast.LENGTH_SHORT).show();
                            finish(); // Close the activity after saving
                        } else {
                            Toast.makeText(RecoverActivity.this, "Failed to save security answers: " + task.getException(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}
