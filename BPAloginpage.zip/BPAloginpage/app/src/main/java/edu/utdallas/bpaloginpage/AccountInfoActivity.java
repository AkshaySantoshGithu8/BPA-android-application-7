package edu.utdallas.bpaloginpage;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class AccountInfoActivity extends AppCompatActivity {

    private TextView firstNameTextView, lastNameTextView, usernameTextView, emailTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_info);

        // Initialize TextViews
        firstNameTextView = findViewById(R.id.firstNameTextView);
        lastNameTextView = findViewById(R.id.lastNameTextView);
        usernameTextView = findViewById(R.id.usernameTextView);
        emailTextView = findViewById(R.id.emailTextView);

        // Retrieve user information and display it
        retrieveUserInfo();
    }

    private void retrieveUserInfo() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String currentUser = LoginActivity.currentUser;

        // Reference to the document in the "passwords" collection
        DocumentReference userDocRef = db.collection("passwords").document(currentUser);

        // Retrieve user information from Firestore
        userDocRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        // Retrieve user information
                        String firstName = document.getString("firstName");
                        String lastName = document.getString("lastName");
                        String username = document.getString("username");
                        String email = document.getString("email");

                        // Display user information in TextViews
                        firstNameTextView.setText("First Name: " + firstName);
                        lastNameTextView.setText("Last Name: " + lastName);
                        usernameTextView.setText("Username: " + username);
                        emailTextView.setText("Email: " + email);
                    }
                } else {
                    // Handle errors
                    Toast.makeText(AccountInfoActivity.this, "Failed to retrieve user information.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
