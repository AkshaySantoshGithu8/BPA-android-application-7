package edu.utdallas.bpaloginpage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class RecoverHomepageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recover_homepage);

        // List of security options
        String[] securityOptions = {
                "Account Information",
                "Change my password",
                "Account Recovery Questions",
                // Add more security options as needed
        };

        // Create an ArrayAdapter to populate the ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, securityOptions);

        // Get the ListView reference and set the adapter
        ListView securityOptionsListView = findViewById(R.id.securityOptionsListView);
        securityOptionsListView.setAdapter(adapter);

        // Set item click listener to handle user selection
        securityOptionsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                handleSecurityOptionClick(position);
            }
        });
    }

    private void handleSecurityOptionClick(int position) {
        switch (position) {
            case 0:
                startActivity(new Intent(RecoverHomepageActivity.this, AccountInfoActivity.class));
                break;
                // "Account Information" clicked
                // Launch the appropriate activity
                //startActivity(new Intent(RecoverHomepageActivity.this, AccountInformationActivity.class));

            case 1:
                startActivity(new Intent(RecoverHomepageActivity.this, PasswordActivity.class));
                // "Change my password" clicked
                // Launch the appropriate activity
               // startActivity(new Intent(RecoverHomepageActivity.this, ChangePasswordActivity.class));
                break;
            case 2:
                // "Account Recovery Questions" clicked
                // Launch the appropriate activity
                startActivity(new Intent(RecoverHomepageActivity.this, RecoverActivity.class));
                break;
            // Add more cases for other security options

            default:
                break;
        }
    }
}
